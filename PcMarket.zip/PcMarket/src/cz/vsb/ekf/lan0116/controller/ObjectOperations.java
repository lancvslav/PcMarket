package cz.vsb.ekf.lan0116.controller;

import java.util.List;

public interface ObjectOperations<O extends Object> {

    /**
     * export structure to csv
     * @param objects 
     */
    void csvExport(List<O> objects);

    /**
     * export structure to Excel file - xls
     *
     * @param objects List of objects
     */
    void excelExport(List<O> objects);

    
    /**
     * export object structure of every item in List
     *
     * @param objects
     */
    void htmlExport(List<O> objects);

}
