package cz.vsb.ekf.lan0116.controller;

/**
 * Purpose of this class is to provide info about desired Vendor
 * @author lancvslav
 */
public class VendorInfo {

    private double units;
    private float percentage;

    public VendorInfo(double units, float percentage) {
        this.units = units;
        this.percentage = percentage;
    }

    public double getUnits() {
        return units;
    }

    public void setUnits(double units) {
        this.units = units;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }
}
