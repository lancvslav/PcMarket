package cz.vsb.ekf.lan0116.loader;

import java.io.IOException;
import java.util.List;

public interface ResourceLoader<O extends Object> {

    /**
     * this method should load data from format specified in individuals implementations
     * @return List of object
     * @throws IOException
     */
    List<O> loadData(String path);
}
