package cz.vsb.ekf.lan0116.record;

public class Timescale {

    private QuarterSales quarter;
    private int year;

    public Timescale(QuarterSales quarter, int year) {
        this.quarter = quarter;
        this.year = year;
    }

    public QuarterSales getQuarter() {
        return quarter;
    }

    public void setQuarter(QuarterSales quarter) {
        this.quarter = quarter;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
