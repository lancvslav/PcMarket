/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.vsb.ekf.lan0116.loader;

import cz.vsb.ekf.lan0116.record.Record;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author lancvslav
 */
public class RecordCsvLoaderTest {

    RecordCsvLoader loader;
    List<Record> records;

    public RecordCsvLoaderTest() {
    }

    @Before
    public void setUp() {
        loader = new RecordCsvLoader();
        records = loader.loadData("resources/resources/data.csv");
    }

    @Test
    public void testLoadData() throws Exception {
        Record record = records.get(0);
        Assert.assertEquals("Fujitsu Siemens", record.getVendor().getName());
    }

}
