package cz.vsb.ekf.lan0116.record;

public class Record {

    private Country country;
    private Timescale timescale;
    private Vendor vendor;
    private double units;
    private float percentage;

    public Record(Country country, Timescale timescale, Vendor vendor, double units, float percentage) {
        this.country = country;
        this.timescale = timescale;
        this.vendor = vendor;
        this.units = units;
        this.percentage = percentage;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Timescale getTimescale() {
        return timescale;
    }

    public void setTimescale(Timescale timescale) {
        this.timescale = timescale;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public double getUnits() {
        return units;
    }

    public void setUnits(double units) {
        this.units = units;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

}
