package cz.vsb.ekf.lan0116.controller;

import cz.vsb.ekf.lan0116.loader.RecordCsvLoader;
import cz.vsb.ekf.lan0116.record.QuarterSales;
import cz.vsb.ekf.lan0116.record.Record;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

public class RerordsOperationsTest {

    private List<Record> records;
    private RerordsOperations recordsOperations;

    public RerordsOperationsTest() {
    }

    @Before
    public void setUp() {
        RecordCsvLoader loader = new RecordCsvLoader();
        records = loader.loadData("resources/resources/data.csv");
        recordsOperations = new RerordsOperations(records, loader.getTotals());
    }

    @Test
    public void testVendorsQuarterSales() {
        List<VendorInfo> info = recordsOperations.vendorsQuarterSales("Dell", "Q4");
        //sales of Dell in 2010 Q4 Slovakia
        double expected = 2525.011404;
        double actual = info.get(0).getUnits();
        Assert.assertEquals(expected, actual, 1.0);
    }

    @Test
    public void testGetVendorsColumns() {
        List<Integer> columnActual = recordsOperations.getVendorsColumns("Dell");
        List<Integer> expected = new ArrayList<>();
        expected.add(2);
        expected.add(9);
        expected.add(11);
        expected.add(22);
        Assert.assertTrue(columnActual.equals(expected));
    }

    @Test
    public void testSortByVendor() {
        List<Record> recordSorted = recordsOperations.sortByVendor(records);
        String nameExp = "ASUS";
        String nameActual = recordSorted.get(0).getVendor().getName();
        Assert.assertEquals(nameExp, nameActual);
    }

    @Test
    public void testSortByUnits() {
        List<Record> recordSorted = recordsOperations.sortByUnits(records);
        double expected = 11455.09902;
        double actual = recordSorted.get(0).getUnits();
        Assert.assertEquals(expected, actual, 1.0);
    }

    @Test
    public void testExcelExport() {
        recordsOperations.excelExport(records);
        File file = new File("exports/recordsExcel.xls");
        assertTrue(file.exists());
    }

    @Test
    public void testCsvExport() {
        recordsOperations.csvExport(records);
        File file = new File("exports/recordsCsv.csv");
        assertTrue(file.exists());
    }

    @Test
    public void testHtmlExport() {
        recordsOperations.htmlExport(records);
        File file = new File("exports/recordsAll.html");
        assertTrue(file.exists());
    }

    @Test
    public void testHtmlYearAndQuarter() {
        recordsOperations.htmlYearAndQuarter(2010, QuarterSales.Q1, "Czech Republic", records);
        File file = new File("exports/recordsYearsQuartersCountry.html");
        assertTrue(file.exists());
    }

}
