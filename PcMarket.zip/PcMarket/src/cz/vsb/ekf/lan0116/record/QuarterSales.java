package cz.vsb.ekf.lan0116.record;

public enum QuarterSales {
    Q1,
    Q2,
    Q3,
    Q4,;

    private double sales;
    private Country country;
    private Vendor vendor;

    public double getSales() {
        return sales;
    }

    public void setSales(double sales) {
        this.sales = sales;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

}
