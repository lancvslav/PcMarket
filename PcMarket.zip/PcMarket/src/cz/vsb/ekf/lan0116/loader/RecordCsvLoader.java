package cz.vsb.ekf.lan0116.loader;

import cz.vsb.ekf.lan0116.record.Timescale;
import cz.vsb.ekf.lan0116.record.Country;
import cz.vsb.ekf.lan0116.record.Vendor;
import cz.vsb.ekf.lan0116.record.Record;
import com.opencsv.CSVReader;
import cz.vsb.ekf.lan0116.record.QuarterSales;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RecordCsvLoader implements ResourceLoader<Record> {

    List<Double> totals;

    private double czQ1totalUnits;
    private double czQ2totalUnits;
    private double czQ3totalUnits;
    private double czQ4totalUnits;

    private double skQ1totalUnits;
    private double skQ2totalUnits;
    private double skQ3totalUnits;
    private double skQ4totalUnits;

    public List<Double> getTotals() {
        return totals;
    }

    /**
     *
     * @param path to file from which you desire to load data
     * @return
     * @throws IOException
     */
    @Override
    public List<Record> loadData(String path) {

        List<Record> records = null;
        try (CSVReader reader = new CSVReader(new FileReader(path), ',', '\'', 1)) {
            records = new ArrayList<>();
            List<String[]> recordsString = reader.readAll();
            Iterator<String[]> iterator = recordsString.iterator();
            while (iterator.hasNext()) {
                String[] record = iterator.next();
                Country country = new Country(record[0]);
                double units = Double.parseDouble(record[3]);
                Vendor vendor = new Vendor(record[2]);
                String[] timeToSplit = record[1].split(" ");
                QuarterSales quarter = QuarterSales.valueOf(timeToSplit[1]);
                quarter.setCountry(country);
                quarter.setSales(units);
                quarter.setVendor(vendor);
                int year = Integer.parseInt(timeToSplit[0]);
                Timescale timelapse = new Timescale(quarter, year);
                Record rec = new Record(country, timelapse, vendor, units, 0);
                records.add(rec);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("file not found" + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("exception occured while loading resource " + ex.getMessage());
        }
        this.calculateTotals(records);
        this.addPercentageColumn(records);
        totals = new ArrayList<>();
        totals.add(czQ1totalUnits);
        totals.add(czQ2totalUnits);
        totals.add(czQ3totalUnits);
        totals.add(czQ4totalUnits);
        totals.add(skQ1totalUnits);
        totals.add(skQ2totalUnits);
        totals.add(skQ3totalUnits);
        totals.add(skQ4totalUnits);
        return records;
    }

    /**
     * iteration to get values to calculate total units per quarters
     *
     * @param records
     */
    private void calculateTotals(List<Record> records) {
        for (Record record : records) {
            String countryName = record.getCountry().getName();
            QuarterSales q = record.getTimescale().getQuarter();
            switch (countryName) {
                case "Czech Republic":
                    switch (q) {
                        case Q1:
                            czQ1totalUnits += record.getUnits();
                            break;
                        case Q2:
                            czQ2totalUnits += record.getUnits();
                            break;
                        case Q3:
                            czQ3totalUnits += record.getUnits();
                            break;
                        case Q4:
                            czQ4totalUnits += record.getUnits();
                            break;
                    }
                    break;
                case "Slovakia":
                    switch (q) {
                        case Q1:
                            skQ1totalUnits += record.getUnits();
                            break;
                        case Q2:
                            skQ2totalUnits += record.getUnits();
                            break;
                        case Q3:
                            skQ3totalUnits += record.getUnits();
                            break;
                        case Q4:
                            skQ4totalUnits += record.getUnits();
                            break;
                    }
                    break;
            }

        }
    }

    /**
     * iteration to set percentages of sales for each record
     *
     * @param records
     */
    private void addPercentageColumn(List<Record> records) {
        for (Record record : records) {
            float percentage = 0;
            String countryName = record.getCountry().getName();
            QuarterSales q = record.getTimescale().getQuarter();
            switch (countryName) {
                case "Czech Republic":
                    switch (q) {
                        case Q1:
                            percentage = (float) (record.getUnits() / czQ1totalUnits) * 100;
                            break;
                        case Q2:
                            percentage = (float) (record.getUnits() / czQ2totalUnits) * 100;
                            break;
                        case Q3:
                            percentage = (float) (record.getUnits() / czQ3totalUnits) * 100;
                            break;
                        case Q4:
                            percentage = (float) (record.getUnits() / czQ4totalUnits) * 100;
                            break;
                    }
                    record.setPercentage(percentage);
                    break;
                case "Slovakia":
                    switch (q) {
                        case Q1:
                            percentage = (float) (record.getUnits() / skQ1totalUnits) * 100;
                            break;
                        case Q2:
                            percentage = (float) (record.getUnits() / skQ2totalUnits) * 100;
                            break;
                        case Q3:
                            percentage = (float) (record.getUnits() / skQ3totalUnits) * 100;
                            break;
                        case Q4:
                            percentage = (float) (record.getUnits() / skQ4totalUnits) * 100;
                            break;
                    }
                    record.setPercentage(percentage);
                    break;
            }
        }
    }

}
