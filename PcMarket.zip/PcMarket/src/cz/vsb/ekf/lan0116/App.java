package cz.vsb.ekf.lan0116;

import cz.vsb.ekf.lan0116.controller.RerordsOperations;
import cz.vsb.ekf.lan0116.controller.VendorInfo;
import cz.vsb.ekf.lan0116.loader.RecordCsvLoader;
import cz.vsb.ekf.lan0116.record.QuarterSales;
import cz.vsb.ekf.lan0116.record.Record;
import java.util.List;

public class App {

    public static void main(String[] args) {
        
        //Note, that all reasonable test are writen, you may check them in test packages

        //Tasks:
        //a) Load the input file and transform it into an object from which you can create a table. 
        //You may use the OpenCSV framework for this purpose.
        RecordCsvLoader loader = new RecordCsvLoader();
        RerordsOperations operations = new RerordsOperations(loader.loadData("resources/resources/data.csv"), loader.getTotals());

        // b) Ascertain the units and share values for a given vendor. Example: I want to know how many units Dell sold 
        //during the given quarter and what its percentage share is.
        List<VendorInfo> info = operations.vendorsQuarterSales("Dell", "Q4");
        System.out.println("Info about dell");
        for (VendorInfo vInf : info) {
            System.out.print("Dell: ");
            System.out.print(vInf.getUnits() + " ");
            System.out.print(String.format("%.2f", vInf.getPercentage()) + "%\n");
        }
        //c) Ascertain which row contains information about a given vendor. Example: I want to know which row contains information about Dell.
        System.out.println("Vendor collumns:");
        System.out.println(operations.getVendorsColumns("Dell"));
        System.out.println("");

        //d) Sort the rows alphabetically (by vendor). 
        System.out.println("Sorted by vendor:");
        List<Record> sortVend = operations.sortByVendor(operations.getRecords());
        for (Record rec : sortVend) {
            System.out.println(rec.getVendor().getName() + " " + rec.getUnits() + " " + String.format("%.2f", rec.getPercentage()) + "%");
        }
        System.out.println("");

        //e) Sort the rows by unit values.
        System.out.println("Sorted by units:");
        List<Record> sortUni = operations.sortByUnits(sortVend);
        for (Record rec : sortUni) {
            System.out.println(rec.getUnits() + " " + rec.getVendor().getName() + " " + String.format("%.2f", rec.getPercentage()) + "%");
        }
        //f) Export the object structure to HTML;
        operations.htmlYearAndQuarter(2010, QuarterSales.valueOf("Q4"), "Czech Republic", operations.getRecords());
        operations.htmlExport(operations.getRecords());

        //g) Export to additional formats (Excel and CSV).        
        operations.excelExport(operations.getRecords());
        operations.csvExport(operations.getRecords());
    }

}
