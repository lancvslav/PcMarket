package cz.vsb.ekf.lan0116.controller;

import cz.vsb.ekf.lan0116.record.Record;
import com.opencsv.CSVWriter;
import cz.vsb.ekf.lan0116.record.QuarterSales;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RerordsOperations implements ObjectOperations<Record> {

    private List<Record> records;

    private final double czQ1totalUnits;
    private final double czQ2totalUnits;
    private final double czQ3totalUnits;
    private final double czQ4totalUnits;
    private final double skQ1totalUnits;
    private final double skQ2totalUnits;
    private final double skQ3totalUnits;
    private final double skQ4totalUnits;

    public RerordsOperations(List<Record> records, List<Double> totals) {
        this.records = records;
        czQ1totalUnits = totals.get(0);
        czQ2totalUnits = totals.get(1);
        czQ3totalUnits = totals.get(2);
        czQ4totalUnits = totals.get(3);
        skQ1totalUnits = totals.get(4);
        skQ2totalUnits = totals.get(5);
        skQ3totalUnits = totals.get(6);
        skQ4totalUnits = totals.get(7);
    }

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }

    /**
     *
     * @param vendorName name of the vendor you want to check information about
     * @param quarter specify quarter, e.g. "Q1", "Q2", so forth
     * @return object VendorInfo providing desired informations
     */
    public List<VendorInfo> vendorsQuarterSales(String vendorName, String quarter) {
        List<VendorInfo> info = new ArrayList<>();
        for (Record record : records) {
            String vendIterName = record.getVendor().getName();
            String qIter = String.valueOf(record.getTimescale().getQuarter());
            String countryName = record.getCountry().getName();
            if (vendorName.equals(vendIterName) && quarter.equals(qIter) && countryName.equals("Czech Republic")) {
                double units = record.getUnits();
                float percentage = record.getPercentage();
                VendorInfo czInfo = new VendorInfo(units, percentage);
                info.add(czInfo);
            }
            if (vendorName.equals(vendIterName) && quarter.equals(qIter) && countryName.equals("Slovakia")) {
                double units = record.getUnits();
                float percentage = record.getPercentage();
                VendorInfo skInfo = new VendorInfo(units, percentage);
                info.add(skInfo);
            }
        }
        return info;
    }

    /**
     *
     * @param vendorName name of the vendor you want to see indexs of lines which it populates
     * @return list with numbers of columns
     */
    public List<Integer> getVendorsColumns(String vendorName) {
        List<Integer> lines = new ArrayList<>();
        int i = 1;
        for (Record record : this.records) {
            if (record.getVendor().getName().equals(vendorName)
                    || record.getVendor().getName().toUpperCase().equals(vendorName)
                    || record.getVendor().getName().toLowerCase().equals(vendorName)) {
                lines.add(i);
            }
            i++;
        }
        return lines;
    }

    /**
     * descending sort of given list of records by name of Vendor
     *
     * @param records
     * @return sorted list
     */
    public List<Record> sortByVendor(List<Record> records) {
        List<Record> sortedList = new ArrayList<>(records);
        Collections.sort(sortedList, (o1, o2) -> o1.getVendor().getName().compareTo(o2.getVendor().getName()));
        return sortedList;
    }

    /**
     * sorts given list of records by name of units
     *
     * @param records
     * @return sorted list
     */
    public List<Record> sortByUnits(List<Record> records) {
        List<Record> sortedList = new ArrayList<>(records);
        Collections.sort(sortedList, (Record r1, Record r2) -> Double.compare(r2.getUnits(), r1.getUnits()));
        return sortedList;
    }

    /**
     * export object structure to excel xls file, using tabulator to separate columns
     * file may prompt warning while opening, you cane safely chose 'yes'
     * values may look wierd at first glance, in this case, change width of column directly in excel app
     *
     * @param records
     */
    @Override
    public void excelExport(List<Record> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("exports/recordsExcel.xls"))) {
            bw.write("Country\tTimescale\tVendor\tUnits\n");
            for (Record record : records) {
                bw.write(record.getCountry().getName() + "\t");
                bw.write(record.getTimescale().getYear() + " " + record.getTimescale().getQuarter() + "\t");
                bw.write(record.getVendor().getName() + "\t");
                bw.write((record.getUnits()) + "\n");
            }
            bw.newLine();
            bw.flush();
        } catch (IOException e) {
            System.err.println("Exception occured while exporting to excel" + e.getMessage());
        }
    }

    /**
     * export object structure to .csv using opencsv framework, CSVWriter to be specific
     *
     * @param records
     */
    @Override
    public void csvExport(List<Record> records) {
        try (CSVWriter writer = new CSVWriter(new FileWriter("exports/recordsCsv.csv"), CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER)) {
            Record record;
            String[] line;
            line = "Country,Timescale,Vendor,Units".split(",");
            writer.writeNext(line);
            for (int i = 0; i < records.size() - 1; i++) {
                record = records.get(i);
                line = (record.getCountry().getName() + "," + record.getTimescale().getYear() + " " + record.getTimescale().getQuarter() + ","
                        + record.getVendor().getName() + "," + record.getUnits()).split(",");
                writer.writeNext(line);
            }
        } catch (IOException ex) {
            System.err.println("Exception occured while exporting to csv" + ex.getMessage());
        }
    }

    /**
     * export whole object structure to .html table, first it prints header by calling method printHeader, next it iterate through the list
     * of records passed in parameter
     *
     * @param records
     */
    @Override
    public void htmlExport(List<Record> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("exports/recordsAll.html"))) {
            try {
                this.printHeader(bw);
            } catch (IOException ex) {
                System.err.println("Exception occured while printing header" + ex.getMessage());
            }
            bw.write("<td>Country</td>\n"
                    + "<td>Timescale</td>\n"
                    + "</tr>");
            for (Record record : records) {
                bw.write("<tr>\n"
                        + "                <td>" + record.getVendor().getName() + "</td>\n"
                        + "                <td>" + record.getUnits() + "</td>\n"
                        + "                <td>" + String.format("%.2f", record.getPercentage()) + "%</td>\n"
                        + "                <td>" + record.getCountry().getName() + "</td>\n"
                        + "                <td>" + record.getTimescale().getYear() + " " + record.getTimescale().getQuarter() + "</td>\n"
                        + "            </tr>");
            }
            bw.write("</table>\n"
                    + "</body>");
            bw.newLine();
            bw.flush();
        } catch (IOException e) {
            System.err.println("IO exception, " + e.getMessage());
        }
    }

    /**
     * export records from given year and quarter to .html table |Vendor|Units|Percentage|
     *
     * @param year specify year e.g. 2010
     * @param quarter specify quarter e.g. "Q4"
     * @param countryName specify country e.g. "Czech Republic"
     * @param records
     */
    public void htmlYearAndQuarter(int year, QuarterSales quarter, String countryName, List<Record> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("exports/recordsYearsQuartersCountry.html"))) {
            try {
                this.printHeader(bw);
            } catch (IOException ex) {
                System.err.println("Exception occured while printing header" + ex.getMessage());
            }
            bw.write("</tr>");
            for (Record record : records) {
                if (record.getTimescale().getYear() == year && record.getTimescale().getQuarter().equals(quarter)
                        && record.getCountry().getName().equals(countryName)) {
                    bw.write("<tr>\n"
                            + "                <td>" + record.getVendor().getName() + "</td>\n"
                            + "                <td>" + record.getUnits() + "</td>\n"
                            + "                <td>" + String.format("%.2f", record.getPercentage()) + "%</td>\n"
                            + "            </tr>");
                }
            }
            bw.write("<tr style=\"background-color: yellow\">\n"
                    + "                <td>Total</td>");
            switch (countryName) {
                case "Czech Republic":
                    switch (quarter) {
                        case Q1:
                            bw.write("<td>" + czQ1totalUnits + "</td>");
                            break;
                        case Q2:
                            bw.write("<td>" + czQ2totalUnits + "</td>");
                            break;
                        case Q3:
                            bw.write("<td>" + czQ3totalUnits + "</td>");
                            break;
                        case Q4:
                            bw.write("<td>" + czQ4totalUnits + "</td>");
                            break;
                    }
                    break;
                case "Slovakia":
                    switch (quarter) {
                        case Q1:
                            bw.write("<td>" + skQ1totalUnits + "</td>");
                            break;
                        case Q2:
                            bw.write("<td>" + skQ2totalUnits + "</td>");
                            break;
                        case Q3:
                            bw.write("<td>" + skQ3totalUnits + "</td>");
                            break;
                        case Q4:
                            bw.write("<td>" + skQ4totalUnits + "</td>");
                            break;
                    }
                    break;
            }

            bw.write("<td>100%</td>\n"
                    + "            </tr>");
            bw.write("</table>\n"
                    + "</body>");
            bw.newLine();
            bw.flush();
        } catch (IOException e) {
            System.err.println("IO exception, " + e.getMessage());
        }
    }

    /**
     * private method which prints head of html file and set style for required table
     *
     * @param bw
     * @throws IOException
     */
    private void printHeader(BufferedWriter bw) throws IOException {
        bw.write("<html>\n"
                + "    <head>\n"
                + "        <style>\n"
                + "            table{\n"
                + "                font-family: sans-serif;\n"
                + "                text-align: center;\n"
                + "                width: 700;\n"
                + "                border: 1px solid black;\n"
                + "                margin: 0px;\n"
                + "                border-collapse: collapse;\n"
                + "            } \n"
                + "            tr{\n"
                + "                border: 1px solid black;\n"
                + "                margin: 0px;\n"
                + "            }\n"
                + "            td{\n"
                + "                width: 33%;\n"
                + "                border: 1px solid black;\n"
                + "                margin: 0px;\n"
                + "            }\n"
                + "        </style>\n"
                + "    </head>\n"
                + "    <body>\n");
        bw.write("<table>\n"
                + "            <tr style=\"background-color: lightgrey\">\n"
                + "                <td>Vendor</td>\n"
                + "                <td>Units</td>\n"
                + "                <td>Share</td>\n");
    }
}
